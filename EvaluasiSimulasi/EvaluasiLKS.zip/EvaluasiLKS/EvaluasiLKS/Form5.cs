﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Migrations;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvaluasiLKS
{
    public partial class Form5 : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        bool isCreated = false;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            bindingSource1.DataSource = entities.HeroSkills.ToList();
            bindingSource2.DataSource = entities.Heroes.ToList();
            bindingSource3.DataSource = entities.Skills.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                Double power = Convert.ToDouble(textBox1.Text);
                HeroSkill hs = new HeroSkill
                {
                    HeroID = (int)comboBox3.SelectedValue,
                    SkillID = (int)comboBox4.SelectedValue,
                    Power = power
                };
                entities.HeroSkills.Add(hs);
                entities.SaveChanges();

                bindingSource1.DataSource = entities.HeroSkills.ToList();
                dataGridView1.Refresh();
                disable();
                MessageBox.Show("Data Hero Skill Succsessfuly Added");
            }
        }

        public void disable()
        {
            textBox1.Text = "";
            button1.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (bindingSource1.Current is HeroSkill hcupu)
                entities.HeroSkills.AddOrUpdate(hcupu);
                entities.SaveChanges();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            disable();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            var heros = entities.Heroes.Where(f => f.Name.Contains(textBox1.Text)).ToList();
            foreach (var her in heros)
            {
                bindingSource1.DataSource = entities.HeroSkills.Where(f => f.HeroID == her.ID).ToList();
            }
            if (textBox2.Text == "")
            {
                bindingSource1.DataSource = entities.HeroSkills.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (bindingSource1.Current is HeroSkill hs)
            {
                entities.HeroSkills.Remove(hs);
                entities.SaveChanges();

                bindingSource1.DataSource = entities.HeroSkills.ToList();
                dataGridView1.Refresh();
                MessageBox.Show("Data Hero Skill Succsessfuly Deleted");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bindingSource1.Current is HeroSkill hs)
            {
                comboBox3.SelectedValue = hs.SkillID;
                comboBox2.SelectedValue = hs.HeroID;
                textBox1.Text = hs.Power.ToString();

                button1.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = false;
            }
        }
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].DataBoundItem is HeroSkill hs)
            {
                if (e.ColumnIndex == heroIDDataGridViewTextBoxColumn.Index)
                {
                    e.Value = hs.Hero.Name;
                }
                if (e.ColumnIndex == skillIDDataGridViewTextBoxColumn.Index)
                {
                    e.Value = hs.Skill.Name;
                }
                if (e.ColumnIndex == powerDataGridViewTextBoxColumn.Index)
                {
                    var format = String.Format("{0:#,0}", hs.Power);
                    e.Value = format;
                }
            }
        }
    }
}
